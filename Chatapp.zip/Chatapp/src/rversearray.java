/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class rversearray {
    

public static void main(String args[]){
     int array[]={1,2,4,5,6};
     int x[]=new int[array.length];
     int indx=0;
     for(int i=array.length-1;i>=0;i--){
         x[indx]=array[i];
         indx++;
     }
     for(int j=0;j<array.length;j++){
         System.out.println(x[j]+"");
         
     }
     
     
      
}
}