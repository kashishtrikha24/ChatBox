/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
import java.util.*;
public class chocolate {
    public static void main(String args[]){
    int[] arr={7,3,2,4,9,15,56};
    int m=3;
     int min=Integer.MAX_VALUE;
    Arrays.sort(arr);
    for(int i=0;i<arr.length-m;i++){
        int diff=arr[i+m-1]-arr[i];
    
    if(diff<min){
        min=diff;
}
    }
    System.out.println(min);
    }
    }